import react,{ Component } from "react";
class Mango extends Component {

render() {

    return (
        <div>
            <h1>am fine</h1>
        </div>
    )
}


}
export default Mango;