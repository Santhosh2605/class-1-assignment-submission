import react from "react";

function Pine(){
    return(
        <div>
            <h1>welcome</h1>
            
        </div>
    )
}
export default Pine;