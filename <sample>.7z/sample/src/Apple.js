import react from "react";

function Apple(){
    return(
        <div>
            <h1>Santhosh</h1>
            
        </div>
    )
}
export default Apple;