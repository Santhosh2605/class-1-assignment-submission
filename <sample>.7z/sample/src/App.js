import logo from './logo.svg';
import './App.css';
import Apple from './Apple';
import Mango from './Mango';
import Pine from './Pine';

function App() {
  return (
    <div>
      <h1>how are you</h1>
      <Apple />
      <Mango />
      <Pine />
    </div>
  );
}

export default App;
